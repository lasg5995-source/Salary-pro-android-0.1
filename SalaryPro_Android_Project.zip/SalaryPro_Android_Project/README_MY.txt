Salary Pro — Android Source Project
Features:
- Myanmar + Chinese interface
- Monthly salary and daily wage modes
- Unlimited employee records (limited by device storage)
- OT hours/rate, holiday/other OT pay, meal/transport/other allowances, deductions
- Add, edit, delete, search employees
- Monthly totals, CSV export (Excel-compatible), JSON backup/restore, print/PDF
- Local offline storage

Important:
This is the source project, not a ready-to-install APK. Open the project in Android Studio, sync Gradle, then choose Build > Build APK(s). An internet connection is needed for the first Gradle dependencies/build setup. After installed, the app's calculator and records work offline.
Pay estimates must be checked against Thailand law and company rules. OT rate is entered manually.
